# from flask import Flask, request
from Dialog import Dialog
from Handler import Handler
from Response import Responser
from StartDialog import StartDialog
from TimeoutDialog import TimeoutDialog
from MiddlewareDialog import MiddleWareDialog
from globalStorage import *
import openai
from threading import Thread
import random
from YandexMusicApi import YandexMusicApi
from MusicRecomender import MusicRecommender, MusicRecommenderException


def find_music_def(event):
    if 'song_name' not in event['state']['session']:
        text = ['Назовите мне песню, а я подберу вам похожие', 'Предложите мне название песни, а я найду вам похожие',
                'К какой песне вы бы хотели подобрать похожие?', 'Назовите песню, чтобы я сделала подборку похожих']
        message = random.choice(text)
        return {
            "text": message,
            "tts": message,
            "buttons": [],
            "session_state": {
                "branch": "find_music",
                "song_name": "",
                "find_music": ""
            }
        }
    else:
        if 'access_token' in event['state']['user']:
            yandex_music_api = YandexMusicApi(event['state']['user']['access_token'])
        return {
            "text": "Напишите название группы или исполнителя",
            "tts": "Напишите название группы",
            "buttons": [],
            "session_state": {
                "branch": "find_music",
                "find_music_completed": "",
                "song_name": event["request"]["original_utterance"]
            }
        }


def find_music_completed_def(event):
    try:
        if 'access_token' in event['state']['user']:
            yandex_music_api = YandexMusicApi(event['state']['user']['access_token'])
            result = yandex_music_api.song_validate(event['state']['session']['song_name'], event["request"]["original_utterance"])

            if result:
                text = ['Вот список похожих песен:\n', 'Вот подборка похожих песен:\n']
                music = music_recomender.choose_music(event['state']['session']['song_name'], event["request"]["original_utterance"])
                message = random.choice(text)
                for i in range(len(music['song_names'])):
                    message += f'{i + 1}. "{music["song_names"][i]}" by {music["band_names"][i]} \n'

                message += "Если хотите поставить лайк на песню - напишите ее номер"

                if len(music["song_names"]) != 0:
                    return {
                            "text": message,
                            "tts": message,
                            "buttons": [
                                "Главное меню"
                            ],
                            "session_state": {
                                "branch": "find_music_completed",
                                "music_list": music,
                            }
                        }
                else:
                    return {
                            "text": 'Песни по вашему запросу не найдены :(',
                            "tts": 'Песни по вашему запросу не найдены',
                            "buttons": [
                                "Главное меню"
                            ],
                            "session_state": {
                                "branch": "main_menu",
                                "music_list": music,
                            }
                        }
            else:
                return {
                    "text": 'Нам кажется, что вы ввели несуществующую песню или допустили ошибку, попробуй еще раз',
                    "tts": 'Нам кажется, что вы ввели несуществующую песню или допустили ошибку, попробуй еще раз',
                    "buttons": [
                        "Главное меню"
                    ],
                    "session_state": {
                        "branch": "main_menu",
                    }
                }
    except:
        return {
            "text": "Извините, произошла непредвиденная ошибка, попробуйте позже \n"
                    "Так же хотим напомнить, что данная функция пока что не работает с русскими песнями",
            "tts": "Извините, произошла непредвиденная ошибка, попробуйте позже."
                    "Так же хотим напомнить, что данная функция пока что не работает с русскими песнями",
            "buttons": [
                "Главное меню"
            ],
            "session_state": {
                "branch": "find_music_completed",
                "find_music_completed": ""
            }
        }


def authorization_def(event):
    return {
            "text":
                """
Для использование некоторых функций навыка требуется авторизация\n
Для авторизации скачайте расширение для вашего браузера (Ссылки находятся ниже в кнопках)\n
После чего авторизируйтесь и нажмите кнопку "скопировать токен"\n
Далее напишите "Ввести токен" в навыке и отправьте скопированный токен.
                """,
            "tts": """
Для использования навыка вам следует пройти авторизацию на устройстве с экраном
Для использование некоторых функций навыка требуется авторизация
Для авторизации скачайте расширение для вашего браузера (Ссылки находятся ниже в кнопках)
После чего авторизируйтесь и нажмите кнопку "скопировать токен"
Далее скажите "Ввести токен" в навыке и отправьте скопированный токен.
""",
            "buttons": [
                {
                    'title': 'Расширение для Google Chrome',
                    'url': 'https://chrome.google.com/webstore/detail/yandex-music-token/lcbjeookjibfhjjopieifgjnhlegmkib',
                    'hide': False
                },
                {
                    'title': 'Расширение для Mozilla FireFox',
                    'url': 'https://addons.mozilla.org/en-US/firefox/addon/yandex-music-token/',
                    'hide': False
                },
                "Ввести токен"
            ],
            "session_state": {
                "branch": "authorization"
            },
            "user_state_update": {
                "access_token": None
            },
    }


def get_access_token_def(event):
    if "access_token" in event['state']['user']:
        try:
            yandex_music_api = YandexMusicApi(event["request"]["original_utterance"])
            yandex_music_api.check_token()
            return {
                "text": "Вы успешно прошли прошли авторизацию!",
                "tts": "Вы успешно прошли прошли авторизацию!",
                "buttons": [
                    "Главное меню"
                ],
                "session_state": {
                    "branch": "get_access_token"
                },
                "user_state_update": {
                    "access_token": event["request"]["original_utterance"]
                },
            }
        except:
            return {
                "text": "Ваш токен оказался невалидным, попробуйте еще раз.\nВведите ваш токен:",
                "tts": "Ваш токен оказался невалидным, попробуйте еще раз. Введите ваш токен",
                "buttons": [
                    "Главное меню"
                ],
                "session_state": {
                    "branch": "get_access_token",
                    "get_access_token": ""
                },
                "user_state_update": {
                    "access_token": "<token>"
                },
            }
    else:
        return {
            "text": "Введите ваш токен:",
            "tts": "Введите ваш токен",
            "buttons": [
                "Главное меню"
            ],
            "session_state": {
                "branch": "get_access_token",
                "get_access_token": ""
            },
            "user_state_update": {
                "access_token": "<token>"
            },
        }


def main_menu_def(event):
    return {
        "card": {
            "type": "BigImage",
            "image_id": "997614/bfada651fa355c92fe73",
            "title": "ГЛАВНОЕ МЕНЮ",
            "description":
                """
                *тестировщиков просим посетить раздел "информация для тестировщиков"*
                Добро пожаловать в навык "Менеджер музыки"! Для того, чтобы узнать функционал навыка скажите: 'Что ты умеешь?'\n
Для многих функций навыка требуется авторизация. Для того, чтобы авторизироваться скажите: Авторизация.""",
        },
        "text": "text",
        "tts":
            """
        тестировщиков просим посетить раздел "информация для тестировщиков", для этого скажите: Информация для тестировщиков.
        Добро пожаловать в навык "Менеджер музыки"! Для того, чтобы узнать функционал навыка скажите: 'Что ты умеешь?'\n
Для многих функций навыка требуется авторизация. Для того, чтобы авторизироваться скажите: Авторизация.""",
        "buttons": [
            "информация для тестировщиков",
            "Подбери песни",
            "Отсортируй плейлист",
            "Добавь с YouTube",
            "Авторизация",
            "Помощь",
            "Что ты умеешь",
            "Выход"
        ],
        "session_state": {
            "branch": "main_menu"
        }
    }


def back_def(event):
    try:
        return dialog_handler.dialogs_dict[dialog_handler.get_state(event)].last_state.get_response_info(event)
    except:
        return main_menu.get_response_info(event)


def help_menu_def(event):
    return {
        "text": """
Вы открыли раздел 'Помощь'.\n
Здесь я могу подробно рассказать про свои возможности.\n
Также вы можете задать вопрос разработчикам навыка или узнать, как связаться с ними.
                """,
        "tts": "Вы открыли раздел 'Помощь'. Здесь я могу подробно рассказать про свои возможности. Также вы можете задать вопрос разработчикам навыка или узнать, как связаться с ними.",
        "buttons": [
            "Как связаться с разработчиками?",
            "Расскажи про возможности",
            "Задать вопрос",
            "Что ты умеешь",
            "Назад"
        ],
        "session_state": {
            "branch": "help_menu"
        }
    }


def connect_with_developers_def(event):
    text = ['Вот контакты разработчиков:\n', 'Контакты для связи с разработчиками:\n',
            'Чтобы связаться с разработчиками воспользуйтесь контактами:\n'
            ]
    message = random.choice(text)
    contacts = "*Контакты разработчиков*"
    return {
        "text": message + contacts,
        "tts": message + contacts,
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "connect_developers"
        }
    }


def skills_def(event):
    return {
        "text": """
В этом навыке вы можете предложить песню, а я порекомендую вам подборку похожих, и вы сможете добавить их в раздел "Моя музыка" приложения Яндекс музыка по вашей просьбе.\n
Кроме того, доступна сортировка плейлиста с вашими понравившимися песнями по жанрам. Данная функция создаст у вас несколько плейлистов на которые разделит ваши любимые песни, для более удобного поиска песен под настроение\n
Также доступен перенос музыки из YouTube в приложение Яндекс музыка. Если вам понравиться какой-либо ремикс/кавер (Или что-либо другое) на какую-либо песню, отправив ссылку на видео с этой композициией вы сможете перенести ее к себе в Яндекс музыку\n

""",
        "tts": """В этом навыке вы можете предложить песню, а я порекомендую вам подборку похожих, и вы сможете добавить их в раздел "Моя музыка" приложения Яндекс музыка по вашей просьбе.
Кроме того, доступна сортировка плейлиста с вашими понравившимися песнями по жанрам. Данная функция создаст у вас несколько плейлистов на которые разделит ваши любимые песни, для более удобного поиска песен под настроение
Также доступен перенос музыки из YouTube в приложение Яндекс музыка. Если вам понравиться какой-либо ремикс/кавер (Или что-либо другое) на какую-либо песню, отправив ссылку на видео с этой композициией вы сможете перенести ее к себе в Яндекс музыку""",
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "skills"
        }
    }


def sort_playlist_def(event):
    if 'access_token' in event['state']['user']:
        yandex_music_api = YandexMusicApi(event['state']['user']['access_token'])
        th = Thread(target=yandex_music_api.sort_playlist)
        th.start()
        return {
            "text": "Сортировка была успешно запущена. Загляните в свои плейлисты через некоторое время, чтобы увидеть результат",
            "tts": "Сортировка была успешно запущена. Загляните в свои плейлисты через некоторое время, чтобы увидеть результат",
            "buttons": [
                "Главное меню",
            ],
            "session_state": {
                "branch": "main_menu"
            }
        }
    else:
        return {
            "text": "Вы не авторизированы, для того, чтобы отсортировать плейлист перейдите в главное меню и авторизируйтесь",
            "tts": "Вы не авторизированы, для того, чтобы отсортировать плейлист перейдите в главное меню и авторизируйтесь",
            "buttons": [
                "Главное меню",
            ],
            "session_state": {
                "branch": "sort_playlist",
            }
        }


def add_song_def(event):
    if 'access_token' in event['state']['user']:
        tokens = event['request']['nlu']['tokens']
        for i in tokens:
            try:
                song_index = int(i)
                break
            except:
                pass

        try:
            song = event['state']['session']['music_list']['song_names'][song_index - 1] + ' ' + event['state']['session']['music_list']['band_names'][song_index - 1]
        except:
            return {
                "text": "Индекс песни не был найден в вашем запросе, попробуйте еще раз",
                "tts": "Индекс песни не был найден в вашем запросе, попробуйте еще раз",
                "buttons": [
                    "Главное меню",
                ],
                "session_state": {
                    "branch": "add_song",
                    "music_list": event['state']['session']["music_list"]
                }
            }

        try:
            yandex_music_api = YandexMusicApi(event['state']['user']['access_token'])
            result = yandex_music_api.like_song(song)
            if result == "error":
                return {
                    "text": "Песня по какой-то причине не была лайкнута, попробуйте еще раз",
                    "tts": "Песня по какой-то причине не была лайкнута, попробуйте еще раз",
                    "buttons": [
                        "Главное меню",
                    ],
                    "session_state": {
                        "branch": "add_song",
                        "music_list": event['state']['session']["music_list"]
                    }
                }
            else:
                text = ['Трек успешно добавлен! Могу добавить что-то еще по вашему желанию.',
                        'Песня была лайкнута, хотите лайкнуть что-то еще?',
                        'Трек добавлен, можете наслаждаться прослушиванием! Желаете добавить что-то еще?'
                    ]
                message = random.choice(text)
                return {
                    "text": message,
                    "tts": message,
                    "buttons": [
                        "Главное меню",
                    ],
                    "session_state": {
                        "branch": "add_song",
                        "music_list": event['state']['session']["music_list"]
                    }
                }
        except:
            return {
                    "text": "Песня по какой-то причине не была лайкнута, попробуйте еще раз",
                    "tts": "Песня по какой-то причине не была лайкнута, попробуйте еще раз",
                    "buttons": [
                        "Главное меню",
                    ],
                    "session_state": {
                        "branch": "add_song",
                        "music_list": event['state']['session']["music_list"]
                    }
                }

    else:
        return {
            "text": "Вы не авторизированы, для того, чтобы лайкать песни перейдите в главное меню и авторизируйтесь",
            "tts": "Вы не авторизированы, для того, чтобы лайкать песни перейдите в главное меню и авторизируйтесь",
            "buttons": [
                "Главное меню",
            ],
            "session_state": {
                "branch": "add_song",
                "music_list": event['state']['session']["music_list"]
            }
        }


def question_developers_def(event):
    text = ['Напишите ваш вопрос, чтобы я отправила его разработчикам', 'Задайте вопрос, и я отправлю его разработчикам']
    message = random.choice(text)
    return {
        "text": message + " (пока не работает)",
        "tts": message + " (пока не работает)",
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "question"
        }
    }


def exit_menu_def(event):
    if 'exit_opinion' in event['state']['session']:
        yes_list = ['да', 'конечно', 'угу', 'ага', 'точно', 'именно', "выйди", "выход"]
        no_list = ['нет', 'не', 'ноуп', 'никогда', 'ненадо', 'ненужно']
        if event['request']['command'] in yes_list:
            text = ['Было очень приятно вам помочь! С нетерпением жду, как смогу сделать это снова, Ня!',
                    'Была рада вам помочь! Надеюсь еще увидимся, ня!',
                    'Хорошего дня! Если понадоблюсь, обращайтесь, ня!',
                    'Была рада провести с вами время! Жду, не дождусь, когда смогу помочь вам снова, ня!'
                    ]
            message = random.choice(text)
            return {
                "text": message,
                "tts": message,
                "buttons": [
                ],
                "end_session": True,
                "session_state": {
                    "branch": "exit_menu"
                }
            }
        elif event['request']['command'] in no_list:
            return {
                "text": 'Вот и правильно!',
                "tts": 'Вот и правильно!',
                "buttons": [
                    "Главное меню",
                    "Назад"
                ],
                "session_state": {
                    "branch": "exit_menu"
                }
            }
    else:
        text = ['Вы точно хотите выйти?', 'Вы уверены что хотите выйти?', 'Желаете выйти из навыка?']
        message = random.choice(text)
        return {
            "text": message,
            "tts": message,
            "buttons": [
                "Да",
                "Нет",
                "Главное меню",
                "Назад"
            ],
            "session_state": {
                "branch": "exit_menu",
                'exit_menu': "",
                'exit_opinion': ""
            }
        }


def what_you_can_def(event):
    return {
        "text":
"""
Я могу сделать подборку похожих песен, по предложенной вами и добавить их в раздел "Моя Музыка" приложения яндекс музыка. Для этого скажите: Подбери песни. \n
Кроме того, в мои умения входит сортировка вашей любимой музыки по жанрам, для этого скажите: Отсортируй плейлист. А так же возможен перенос музыки из YouTube в Яндекс Музыку, но данная функция пока не готова.
""",
        "tts": """Я могу сделать подборку похожих песен, по предложенной вами и добавить их в раздел "Моя Музыка" приложения яндекс музыка. Для этого скажите: Подбери песни. \n
Кроме того, в мои умения входит сортировка вашей любимой музыки по жанрам, для этого скажите: Отсортируй плейлист. А так же возможен перенос музыки из YouTube в Яндекс Музыку, но данная функция пока не готова.
""",
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "main_menu"
        }
    }


def get_youtube_def(event):
    return {
        "text": "Данная функция пока не работает",
        "tts": "Данная функция пока не работает",
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "get_youtube",
        }
    }


def info_def(event):
    return {
        "text":
            """
Справка для тестировщиков:\n
Поиск песен работает только для английский песен, создание функции для русских в разработке.\n
Иногда выдаются несуществующие песни, проверка на валидность песен в разработке.\n
Сложная авторизация т.к. используется неофициальная api Яндекс музыки. Упрощение в разработке, в случае неудачи будет добавлен способ получения токена для смартфонов.\n
Скачивание с ютуб на финишной прямой, идет разработка функции, которая будет добавлять песню не в созданный нами плейлист, а в любимое пользователя.\n
Иногда так же могут выскакивать какие-либо ошибки которые мы обрабатываем, подробные описания самих ошибок и исключение случаев их появления в разработке.\n
Алиса плохо считывает английские слова, разработка обработчика оригинального выражения пользователя  в разработке\n
"Верстка" текста, а так же голосового вывода так же в разработке.\n
С любовью\n
Капитан команды NullPointerExeption\n
Караваев Иван
            """,
        "tts":
            """
Справка для тестировщиков:\n
Поиск песен работает только для английский песен, создание функции для русских в разработке.\n
Иногда выдаются несуществующие песни, проверка на валидность песен в разработке.\n
Сложная авторизация т.к. используется неофициальная api Яндекс музыки. Упрощение в разработке, в случае неудачи будет добавлен способ получения токена для смартфонов.\n
Скачивание с ютуб на финишной прямой, идет разработка функции, которая будет добавлять песню не в созданный нами плейлист, а в любимое пользователя.\n
Иногда так же могут выскакивать какие-либо ошибки которые мы обрабатываем, подробные описания самих ошибок и исключение случаев их появления в разработке.\n
Алиса плохо считывает английские слова, разработка обработчика оригинального выражения пользователя  в разработке\n
"Верстка" текста, а так же голосового вывода так же в разработке.\n
С любовью\n
Капитан команды NullPointerExeption\n
Караваев Иван
            """,
        "buttons": [
            "Главное меню",
            "Назад"
        ],
        "session_state": {
            "branch": "info",
        }
    }


info = Dialog([], info_def, {"информация", "тестировщиков"})
find_music = Dialog([], find_music_def, {"найди", "подбери", "похожие", "треки", "произведения", "композиции", "музыку"})
add_song = Dialog([], add_song_def, set({}), always=True)
find_music_completed = TimeoutDialog([add_song], find_music_completed_def, set({}))
sort_playlist = Dialog([], sort_playlist_def, {"отсортируй", "плейлист", "сортируй", "сортировка", "любимые", "раскидай"})
get_youtube = Dialog([], get_youtube_def, {"скачай", "ютуб", "youtube", "загрузи"})
connect_with_developers = Dialog([], connect_with_developers_def, {"связаться", "разработчиками", "создателями", "контакты", "раскидай", "жанрам", "разложи"})
skills = Dialog([], skills_def, {"возможности", "способности", "расскажи", "скажи", "опиши", "умения", "функции", "функционал"})
question_developers = Dialog([], question_developers_def, {"задать", "вопрос", "спросить"})
get_access_token = Dialog([], get_access_token_def, {"ввести", "токен"})
authorization = Dialog([get_access_token], authorization_def, {"авторизация", "войти", "авторизуй", "авторизуйся"})
main_menu = StartDialog([find_music, authorization, sort_playlist, info, get_youtube], main_menu_def, {"главное", "меню", "страница", "главная"})

exit_menu = MiddleWareDialog([], exit_menu_def, {"выход", "выйти", "выйти"})
back = Dialog([], back_def, {"назад", "вернись", "отмена"})
what_you_can = MiddleWareDialog([], what_you_can_def, {'ты', 'умеешь', 'можешь'})
help_menu = MiddleWareDialog([connect_with_developers, skills, question_developers], help_menu_def, {"помощь", "помогите", "хелп", "спасите", "подскажи", "помоги"})

info.set_last_state(main_menu)
find_music.set_last_state(main_menu)
sort_playlist.set_last_state(main_menu)
get_youtube.set_last_state(main_menu)
get_access_token.set_next_states_list([get_access_token])
add_song.set_next_states_list([add_song])
add_song.set_last_state(main_menu)
find_music.set_next_states_list([find_music, find_music_completed])
connect_with_developers.set_last_state(help_menu)
skills.set_last_state(help_menu)
question_developers.set_last_state(help_menu)
exit_menu.set_next_states_list([exit_menu])

dialogs_dict = {
    "info": info,
    "main_menu": main_menu,
    "find_music": find_music,
    "add_song": add_song,
    "sort_playlist": sort_playlist,
    "get_youtube": get_youtube,
    "find_music_completed": find_music_completed,
    "connect_developers": connect_with_developers,
    "skills": skills,
    "authorization": authorization,
    "get_access_token": get_access_token,
    "question": question_developers,
    "help_menu": help_menu,
    "what_you_can": what_you_can,
    "exit_menu": exit_menu
}
middlewares_list = [
    back,
    help_menu,
    main_menu,
    what_you_can,
    exit_menu
]

music_recomender = MusicRecommender("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")
dialog_handler = Handler(dialogs_dict, middlewares_list, main_menu)


def handler(event, context):
    return dialog_handler.choose_dialog(event)


# app = Flask(__name__)


# @app.route('/', methods=['POST'])
# def hello():
#     event = request.get_json()
#     response = handler(event, "123")
#     print(response)
#     print(global_storage)
#     return response


# if __name__ == "__main__":
#     app.run()
