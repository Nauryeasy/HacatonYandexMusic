from Dialog import Dialog


class MiddleWareDialog(Dialog):
    pass
